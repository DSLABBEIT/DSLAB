import java.util.Scanner;

public class TokenRing2 {
    private static int token = 0; // Shared token to control access

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of nodes: ");
        int n = sc.nextInt();

        Thread[] threads = new Thread[n]; // Array to hold node threads

        // Initialize and start threads for each node
        for (int i = 0; i < n; i++) {
            final int nodeId = i;
            threads[i] = new Thread(() -> {
                while (true) {
                    try {
                        // Acquire lock to ensure mutual exclusion
                        synchronized (TokenRing.class) {
                            System.out.println("Node " + nodeId + " is ready to send data.");

                            // Simulate sender, receiver, and data input (replace with actual logic)
                            int s = nodeId;
                            int r = (nodeId + 1) % n;
                            String d = "Sample Data";

                            System.out.print("Token passing:");
                            // Print the token passing path
                            for (int j = token; j != s; j = (j + 1) % n) {
                                System.out.print(" " + j + "->");
                            }
                            System.out.println(" " + s);

                            System.out.println("Node " + s + " sending data: " + d);

                            // Forward data to the next node
                            for (int k = (s + 1) % n; k != r; k = (k + 1) % n) {
                                System.out.println("Data " + d + " forwarded by Node " + k);
                            }
                            System.out.println("Node " + r + " received data: " + d);

                            // Update token to sender node
                            token = s;

                            // Simulate delay or processing time
                            Thread.sleep(1000); // Adjust as needed
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            });
            threads[i].start(); // Start node thread
        }

        // Wait for all threads to complete (though they run indefinitely in this example)
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}