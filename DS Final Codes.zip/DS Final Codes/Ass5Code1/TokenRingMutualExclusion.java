import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class TokenRingMutualExclusion {
    private static Semaphore token = new Semaphore(1); // Semaphore for token control
    private static int currentProcess = 0; // Index of the current process
    private static String[] messageBuffer; // Message buffer

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of nodes in the ring: ");
        int numNodes = scanner.nextInt();
        messageBuffer = new String[numNodes];

        for (int i = 0; i < numNodes; i++) {
            new Thread(new Process(i, numNodes)).start();
        }

        // Wait for user input to exit the program
        System.out.println("Press enter to exit...");
        scanner.nextLine(); // Consume the newline character left by nextInt()
        scanner.nextLine(); // Wait for enter key press
        System.out.println("Exiting...");
        System.exit(0);
    }

    static class Process implements Runnable {
        private int processId;
        private int numNodes;

        public Process(int processId, int numNodes) {
            this.processId = processId;
            this.numNodes = numNodes;
        }

        @Override
        public void run() {
            while (true) {
                try {
                    // Non-critical section
                    Thread.sleep(1000);

                    // Entering critical section
                    token.acquire();
                    if (currentProcess == processId) {
                        System.out.println("Process " + processId + " is in the critical section.");

                        // Token passing sequence
                        System.out.print("Token passing:");
                        for (int i = currentProcess, j = currentProcess; (i % numNodes) != processId; i++, j = (j + 1) % numNodes) {
                            System.out.print(" " + j + "->");
                        }
                        System.out.println(" " + processId);

                        // Message handling
                        if (messageBuffer[processId] != null) {
                            System.out.println("Message received by Process " + processId + ": " + messageBuffer[processId]);
                            messageBuffer[processId] = null; // Clear the message buffer after processing
                        }

                        // Message passing logic
                        int receiver = (processId + 1) % numNodes;
                        if (messageBuffer[receiver] == null) {
                            // Send message if the receiver's buffer is empty
                            String message = "Message from Process " + processId;
                            System.out.println("Process " + processId + " sending message: " + message);
                            messageBuffer[receiver] = message;
                        }

                        // Exit critical section
                        System.out.println("Process " + processId + " exits the critical section.");
                        currentProcess = (currentProcess + 1) % numNodes; // Pass the token
                    }
                    token.release();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
