from mpi4py import MPI
import numpy as np

comm = MPI.COMM_WORLD
rank = comm.rank

# Function to distribute elements evenly among processes
def distribute_array(arr, num_procs):
    num_elements = len(arr)
    elements_per_proc = num_elements // num_procs
    remainder = num_elements % num_procs
    displacements = [i * elements_per_proc + min(i, remainder) for i in range(num_procs)]
    counts = [elements_per_proc + 1 if i < remainder else elements_per_proc for i in range(num_procs)]
    return np.array_split(arr, counts, displacements)

if rank == 0:
    arr = np.array([12, 21241, 5131, 1612251, 161, 6, 161, 1613, 161363, 12616, 367, 8363])
    num_procs = comm.Get_size()
    send_buf = distribute_array(arr, num_procs)
else:
    send_buf = None

recv_buf = np.zeros(1, dtype=int)  # Create an array to receive data

send_buf = comm.scatter(send_buf, root=0)
local_sum = np.sum(send_buf)

print("Local sum at rank {0}: {1}".format(rank, local_sum))

comm.Reduce(local_sum, recv_buf, op=MPI.SUM, root=0)

if rank == 0:
    global_sum = recv_buf[0]
    print("Global sum: " + str(global_sum))
