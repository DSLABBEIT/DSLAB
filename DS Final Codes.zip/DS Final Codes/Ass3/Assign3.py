import multiprocessing

def calculate_partial_sum(arr, start, end, result_queue):
    partial_sum = sum(arr[start:end])
    result_queue.put(partial_sum)

def main():
    arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]  # Example array
    n = len(arr)  # Total number of elements
    num_processors = multiprocessing.cpu_count()  # Number of available processors

    chunk_size = n // num_processors  # Number of elements to distribute to each processor

    processes = []
    result_queue = multiprocessing.Queue()

    for i in range(num_processors):
        start = i * chunk_size
        end = (i + 1) * chunk_size if i < num_processors - 1 else n
        p = multiprocessing.Process(target=calculate_partial_sum, args=(arr, start, end, result_queue))
        processes.append(p)
        p.start()

    for p in processes:
        p.join()

    # Collecting partial sums from all processors
    partial_sums = []
    while not result_queue.empty():
        partial_sums.append(result_queue.get())

    # Displaying intermediate sums calculated at different processors
    print("Intermediate sums calculated at different processors:")
    for i, partial_sum in enumerate(partial_sums):
        print(f"Processor {i + 1}: {partial_sum}")

    # Final sum
    final_sum = sum(partial_sums)
    print("Final sum:", final_sum)

if __name__ == "__main__":
    main()
