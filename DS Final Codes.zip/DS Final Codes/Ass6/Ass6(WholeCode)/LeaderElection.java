import java.util.Scanner;

public class LeaderElection {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;
        
        while (true) {
            System.out.println("Leader Election Algorithms");
            System.out.println("1. Bully Algorithm");
            System.out.println("2. Ring Algorithm");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            
            switch (choice) {
                case 1:
                    runBullyAlgorithm();
                    break;
                case 2:
                    runRingAlgorithm();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please enter again.");
            }
        }
    }
    
    public static void runBullyAlgorithm() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int max_processes = sc.nextInt();
        
        Bully bully = new Bully(max_processes);
        
        int choice;
        while (true) {
            System.out.println("Bully Algorithm Menu");
            System.out.println("1. Display processes");
            System.out.println("2. Up a process");
            System.out.println("3. Down a process");
            System.out.println("4. Run election algorithm");
            System.out.println("5. Return to main menu");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            
            switch (choice) {
                case 1:
                    bully.displayProcesses();
                    break;
                case 2:
                    System.out.print("Enter the process number to up: ");
                    int process_id_up = sc.nextInt();
                    bully.upProcess(process_id_up);
                    break;
                case 3:
                    System.out.print("Enter the process number to down: ");
                    int process_id_down = sc.nextInt();
                    bully.downProcess(process_id_down);
                    break;
                case 4:
                    System.out.print("Enter the process number which will perform election: ");
                    int process_id_election = sc.nextInt();
                    bully.runElection(process_id_election);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter again.");
            }
        }
    }
    
    public static void runRingAlgorithm() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of processes: ");
        int max_processes = sc.nextInt();
        
        Ring ring = new Ring(max_processes);
        
        int choice;
        while (true) {
            System.out.println("Ring Algorithm Menu");
            System.out.println("1. Display processes");
            System.out.println("2. Up a process");
            System.out.println("3. Down a process");
            System.out.println("4. Run election algorithm");
            System.out.println("5. Return to main menu");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            
            switch (choice) {
                case 1:
                    ring.displayProcesses();
                    break;
                case 2:
                    System.out.print("Enter the process number to up: ");
                    int process_id_up = sc.nextInt();
                    ring.upProcess(process_id_up);
                    break;
                case 3:
                    System.out.print("Enter the process number to down: ");
                    int process_id_down = sc.nextInt();
                    ring.downProcess(process_id_down);
                    break;
                case 4:
                    System.out.print("Enter the process number which will initiate election: ");
                    int process_id_election = sc.nextInt();
                    ring.initElection(process_id_election);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please enter again.");
            }
        }
    }
}

class Bully {
    int coordinator;
    int max_processes;
    boolean processes[];

    public Bully(int max) {
        max_processes = max;
        processes = new boolean[max_processes];
        coordinator = max;

        System.out.println("Creating processes..");
        for(int i = 0; i < max; i++) {
            processes[i] = true;
            System.out.println("P"+ (i+1) + " created");
        }
        System.out.println("Process P" + coordinator + " is the coordinator");
    }

    void displayProcesses() {
        for(int i = 0; i < max_processes; i++) {
            if(processes[i]) {
                System.out.println("P" + (i+1) + " is up");
            } else {
                System.out.println("P" + (i+1) + " is down");
            }
        }
        System.out.println("Process P" + coordinator + " is the coordinator");
    }

    void upProcess(int process_id) {
        if(!processes[process_id - 1]) {
            processes[process_id - 1] = true;
            System.out.println("Process " + process_id + " is now up.");
        } else {
            System.out.println("Process " + process_id + " is already up.");
        }
    }

    void downProcess(int process_id) {
        if(!processes[process_id - 1]) {
            System.out.println("Process " + process_id + " is already down.");
        } else {
            processes[process_id - 1] = false;
            System.out.println("Process " + process_id + " is down.");
        }
    }

    void runElection(int process_id) {
        coordinator = process_id;
        boolean keepGoing = true;

        for(int i = process_id; i < max_processes && keepGoing; i++) {
            System.out.println("Election message sent from process " + process_id + " to process " + (i+1));

            if(processes[i]) {
                keepGoing = false;
                runElection(i + 1);
            }
        }
    }
}

class Ring {
    int max_processes;
    int coordinator;
    boolean processes[];

    public Ring(int max) {
        coordinator = max;
        max_processes = max;
        processes = new boolean[max];

        for(int i = 0; i < max; i++) {
            processes[i] = true;
            System.out.println("P" + (i+1) + " created.");
        }
        System.out.println("P" + (coordinator) + " is the coordinator");
    }

    void displayProcesses() {
        for(int i = 0; i < max_processes; i++) {
            if(processes[i]) 
                System.out.println("P" + (i+1) + " is up.");
            else
                System.out.println("P" + (i+1) + " is down.");
        }   
        System.out.println("P" + (coordinator) + " is the coordinator");
    }

    void upProcess(int process_id) {
        if(!processes[process_id-1]) {
            processes[process_id-1] = true;
            System.out.println("Process P" + (process_id) + " is up.");
        } else {
            System.out.println("Process P" + (process_id) + " is already up.");
        }
    }

    void downProcess(int process_id) {
        if(!processes[process_id-1]) {
            System.out.println("Process P" + (process_id) + " is already down.");
        } else {
            processes[process_id-1] = false;
            System.out.println("Process P" + (process_id) + " is down.");
        }
    }

    void initElection(int process_id) {
        int[] pid = new int[max_processes];
        int currentIndex = 0;
        
        if (processes[process_id - 1]) {
            pid[currentIndex++] = process_id;
            
            int temp = process_id;

            while (true) {
                temp = (temp + 1) % max_processes;
                if (temp == process_id - 1)
                    break;
                if (processes[temp]) 
                    pid[currentIndex++] = temp + 1;
            }
            
            int max = process_id;
            for (int i = 0; i < currentIndex; i++) {
                if (pid[i] > max)
                    max = pid[i];
            }
            
            coordinator = max;
            System.out.println("Process P" + process_id + " has declared P" + coordinator + " as the coordinator");
        }
    }
}
